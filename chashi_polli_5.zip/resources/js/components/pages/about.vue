<template>

</template>

<script>
export default {
    name: "about"
}
</script>

<style scoped>

</style>
