<?php $__env->startSection('styles'); ?>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@500&display=swap" rel="stylesheet">

    <!-- Styles ok -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet"/>

    <link href="<?php echo e(asset('assets/css/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/js/datetimepicker/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/js/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/themecss/lib.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/js/jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/js/lightslider/lightslider.css')); ?>" rel="stylesheet"/>


    <link href="<?php echo e(asset('assets/css/themecss/so_megamenu.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/themecss/so-categories.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/themecss/so-listing-tabs.css')); ?>" rel="stylesheet"/>
    <link id="color_scheme" href="<?php echo e(asset('assets/css/home3.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet"/>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?> Chashipolli.com <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <header-menu></header-menu>

        <router-view></router-view>

    <footer-section></footer-section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <link rel="stylesheet" property="stylesheet"  href="<?php echo e(asset('assets/css/themecss/cpanel.css')); ?>" type="text/css" media="all"/>

    <!-- Include Libs & Plugins
    ============================================ -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo e(asset('assets/js/jquery-2.2.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/themejs/libs.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/unveil/jquery.unveil.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/countdown/jquery.countdown.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dcjqaccordion/jquery.dcjqaccordion.2.8.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datetimepicker/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datetimepicker/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lightslider/lightslider.js')); ?>"></script>

    <!-- Theme files
    ============================================ -->
    <script src="<?php echo e(asset('assets/js/themejs/application.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/themejs/toppanel.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/themejs/so_megamenu.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/themejs/addtocart.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/themejs/accordion.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/themejs/cpanel.js')); ?>"></script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravels\chashi_polli\resources\views/public.blade.php ENDPATH**/ ?>