<template>

</template>

<script>
export default {
    name: "privacy"
}
</script>

<style scoped>

</style>
