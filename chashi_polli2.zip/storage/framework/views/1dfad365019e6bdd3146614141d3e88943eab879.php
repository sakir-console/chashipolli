<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title', $page_title ?? ''); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body class="common-home res layout-home3">
<div id="app">
    <div id="wrapper" class="wrapper-full banners-effect-7">

        <?php echo $__env->yieldContent('content'); ?>

    </div>

</div>
<?php echo $__env->yieldContent('scripts'); ?>
<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

</body>

</html>
<?php /**PATH F:\Laravels\chashi_polli\resources\views/layouts/app.blade.php ENDPATH**/ ?>