<template>
    <div class="main-container container">
    <div class="moduletable module best-seller clearfix ">

        <div class="main-container">

            <div v-for="(coupon,index) in coupons" :key="coupon.id" class="cards">


                <div class="card card-3">
                    <p class="card__exit"><i class="fa fa-offer"></i></p>
                    <h1 class="card__title">{{coupon.amount}}{{coupon.percentage==1?'%':'Taka'}} discount</h1>
                    <hr>

                    <h2 class="card__title">    <p class="card__apply">Coupon Code: {{coupon.code}}</p></h2>

                </div>


            </div>
        </div>
    </div>
    </div>
</template>

<script>
export default {
    name: "coupon",
    data() {
        return {

            coupons: [],
            msg:'',


        }
    },
    methods: {

        viewCoupon() {

            axios.get(this.$api_url + 'api/v1/view/coupon', {}
            ).then(
                response => {
                    this.result = true;
                    console.log(response);
                    this.coupons = response.data.data;

                    this.msg = '';

                }
            ).catch((error) => {

                this.msg = error.response.data.message;
                console.log(error.response);
            });
        },

    },
    mounted() {

        this.viewCoupon()
    }
}
</script>

<style scoped>

/* CARDS */

.cards {
    display: inline-block;
    flex-wrap: wrap;
    justify-content: space-between;
}

.card {
    margin: 20px;
    padding: 20px;
    width: 325px;
    min-height: 200px;

    grid-template-rows: 20px 50px 1fr 50px;
    border-radius: 10px;
    box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.25);
    transition: all 0.2s;
}

.card:hover {
    box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.4);
    transform: scale(1.01);
}

.card__link,
.card__exit,
.card__icon {
    position: relative;
    text-decoration: none;
    color: rgba(255, 255, 255, 0.9);
}

.card__link::after {
    position: absolute;
    top: 25px;
    left: 0;
    content: "";
    width: 0%;
    height: 3px;
    background-color: rgba(255, 255, 255, 0.6);
    transition: all 0.5s;
}

.card__link:hover::after {
    width: 100%;
}

.card__exit {
    grid-row: 1/2;
    justify-self: end;
}

.card__icon {
    grid-row: 2/3;
    font-size: 30px;
}

.card__title {
    grid-row: 3/4;
    font-weight: 400;
    color: #ffffff;
}

.card__apply {
    grid-row: 4/5;
    align-self: center;
}

/* CARD BACKGROUNDS */

.card-1 {
    background: radial-gradient(#1fe4f5, #3fbafe);
}

.card-2 {
    background: radial-gradient(#fbc1cc, #fa99b2);
}

.card-3 {
    background: radial-gradient(#76b2fe, #b69efe);
}

.card-4 {
    background: radial-gradient(#60efbc, #58d5c9);
}

.card-5 {
    background: radial-gradient(#f588d8, #c0a3e5);
}

/* RESPONSIVE */

@media (max-width: 1600px) {
    .cards {
        justify-content: center;
    }
}

</style>
